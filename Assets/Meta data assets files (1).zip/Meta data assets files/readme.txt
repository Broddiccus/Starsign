Read me File

The files of this pack are from my short game "A Meta Data Game" https://ansimuz.itch.io/a-meta-data-game

You as a Patreon Supporter are granted the permission to use these files on your personal or commercial projects. Credit is not required but appreciated it.


The downloadable file contains everything you need to start working right away on your game project.

Thanks Again

Created by Ansimuz www.ansimuz.com
Visit my site for free resources at www.pixelgameart.org

follow me at twitter @ansimuz
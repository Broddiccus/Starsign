Pixel Love Font
Font designed and created by Mirz (Michelle Lehmann)
=====================================

This font is best used at 6pt in most graphic programs.

This font may be used for personal and commercial use. 
Commercial use is restricted to incorporation in a project
or design. You may not profit from direct sale/distribution
of this font.  Please see my TOS page at
http://scriptmonkeys.us/monkeys/2010/05/08/graphics-pixel-font-use-license/
for more details. 

I am generally very flexible in my terms. If you have questions
or would like to discuss a special situation, please contact me at 
mirzjiles@aol.com for more information.

Background on font display graphic credit BlackHeartedWolf:
http:/blackheartedwolf.deviantart.com

More pixel fonts from Mirz can be found at:
http://www.scriptmonkeys.us
http://mirz123.deviantart.com
/*
 * TINY RPG Demo Code
 * @copyright    2018 Ansimuz
 * @license      {@link https://opensource.org/licenses/MIT | MIT License}
 * Get free assets and code at: www.pixelgameart.org
 * */

var audioFlag = true;
var attackFlag = false;
var game;
var player;
var gameWidth = 272;
var gameHeight = 192;
var globalMap;
var enemies_group;
var loot_group;
var objects_group;
var player_state;
var PLAYER_STATE = {
    LEFT: 0,
    RIGHT: 1,
    UP: 2,
    DOWN: 3,
    WALKING_LEFT: 4,
    WALKING_RIGHT: 5,
    WALKING_UP: 6,
    WALKING_DOWN: 7
};
var hurtFlag;
var cameraTarget = null;
var exit;
var exitFlag = false;

window.onload = function () {

    game = new Phaser.Game(gameWidth, gameHeight, Phaser.AUTO, "");
    game.state.add('Boot', boot);
    game.state.add('Preload', preload);
    game.state.add('TitleScreen', titleScreen);
    game.state.add('PlayGame', playGame);
    game.state.add('GameOver', gameOver);
    //
    game.state.start("Boot");
}

var boot = function (game) {
};
boot.prototype = {
    preload: function () {
        this.game.load.image("loading", "assets/sprites/loading.png");
    },
    create: function () {

        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        game.renderer.renderSession.roundPixels = true; // blurring off
        this.game.state.start("Preload");
    }
}

var preload = function (game) {
};
preload.prototype = {

    preload: function () {
        var loadingBar = this.add.sprite(game.width / 2, game.height / 2, "loading");
        loadingBar.anchor.setTo(0.5);
        game.load.setPreloadSprite(loadingBar);
        // load title screen
        game.load.image("title-bg", "assets/sprites/title-screen-bg.png");
        game.load.image("title", "assets/sprites/title-screen.png");
        game.load.image("enter", "assets/sprites/press-enter-text.png");
        game.load.image("credits", "assets/sprites/credits-text.png");
        game.load.image("instructions", "assets/sprites/instructions.png");
        game.load.image("gameover", "assets/sprites/game-over.png");

        // tileset
        game.load.image("tileset", "assets/environment/tileset.png");
        game.load.image("tileset-foreground", "assets/environment/tileset-foreground.png");
        game.load.image("collisions", "assets/environment/collisions.png");
        game.load.tilemap("map", "assets/maps/map.json", null, Phaser.Tilemap.TILED_JSON);
        // atlas
        game.load.atlasJSONArray("atlas", "assets/atlas/atlas.png", "assets/atlas/atlas.json");
        game.load.atlasJSONArray("atlas-props", "assets/atlas/atlas-props.png", "assets/atlas/atlas-props.json");

        // audio
        game.load.audio("music", ["assets/sound/rpg_dungeon01.ogg", "assets/sound/rpg_dungeon01.mp3"]);
        game.load.audio("hurt", ["assets/sound/hurt.ogg", "assets/sound/hurt.mp3"]);
        game.load.audio("slash", ["assets/sound/slash.ogg", "assets/sound/slash.mp3"]);
        game.load.audio("item", ["assets/sound/item.ogg", "assets/sound/item.mp3"]);
        game.load.audio("enemy-death", ["assets/sound/enemy-death.ogg", "assets/sound/enemy-death.mp3"]);


    },
    create: function () {
        this.game.state.start("TitleScreen");
    }

}

var titleScreen = function (game) {
};
titleScreen.prototype = {
    create: function () {
        background = game.add.tileSprite(0, 0, gameWidth, gameHeight, "title-bg");
        this.title = game.add.image(game.width / 2, 130, "title");
        this.title.anchor.setTo(0.5, 1);
        var tween = game.add.tween(this.title);
        tween.to({y: 130 + 10}, 800, Phaser.Easing.Linear.In).yoyo(true).loop();

        tween.start();
        //
        this.pressEnter = game.add.image(game.width / 2, game.height - 35, "enter");
        this.pressEnter.anchor.setTo(0.5);
        //
        var startKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
        startKey.onDown.add(this.startGame, this);
        this.state = 1;
        //
        game.time.events.loop(900, this.blinkText, this);
        //
        var credits = game.add.image(game.width / 2, game.height - 15, "credits");
        credits.anchor.setTo(0.5);
    },
    startGame: function () {
        if (this.state == 1) {
            this.state = 2;
            this.title2 = game.add.image(game.width / 2, game.height / 2, 'instructions');
            this.title2.anchor.setTo(0.5);
            this.title.destroy();
        } else {
            this.game.state.start('PlayGame');
        }
    },
    blinkText: function () {
        if (this.pressEnter.alpha) {
            this.pressEnter.alpha = 0;
        } else {
            this.pressEnter.alpha = 1;
        }
    }
}


var gameOver = function (game) {
};
gameOver.prototype = {
    create: function () {
        background = game.add.tileSprite(0, 0, gameWidth, gameHeight, "title-bg");
        this.title = game.add.image(game.width / 2, game.height / 2, 'gameover');
        this.title.anchor.setTo(0.5);

        //
        this.pressEnter = game.add.image(game.width / 2, game.height - 35, "enter");
        this.pressEnter.anchor.setTo(0.5);
        //
        var startKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
        startKey.onDown.add(this.startGame, this);
        this.state = 1;
        //
        game.time.events.loop(900, this.blinkText, this);
        //
        var credits = game.add.image(game.width / 2, game.height - 15, "credits");
        credits.anchor.setTo(0.5);
    },
    startGame: function () {
        this.game.state.start('PlayGame');
    },
    blinkText: function () {
        if (this.pressEnter.alpha) {
            this.pressEnter.alpha = 0;
        } else {
            this.pressEnter.alpha = 1;
        }
    }
}

var playGame = function (game) {
};
playGame.prototype = {
    create: function () {

        this.createTileMap(1);
        this.createExit(25, 5);
        this.createPlayer(8, 5);
        this.bindKeys();
        this.createGroups();
        this.populate();
        this.layer_foreground = globalMap.createLayer("Foreground Layer");
        this.layer_foreground.resizeWorld();
        this.addAudios();
        this.startMusic();
        this.createHud();

        this.createCamera();

    },
    createExit: function (x, y) {
        exit = game.add.sprite(x * 16, y * 16, "atlas-props", "big-stairs-closed");
        exit.animations.add("closed", ["big-stairs-closed"], 1, false);
        exit.animations.add("open", ["big-stairs-down"], 1, false);
        exit.animations.play("closed");
        game.physics.arcade.enable(exit);
    },
    createCamera: function () {

        cameraTarget = game.add.sprite(0, 0, null);

        //cameraTarget.anchor.setTo(0.5);
        game.physics.arcade.enable(cameraTarget);

        cameraTarget.body.setSize(2, 2, 0, 0);

        game.camera.follow(cameraTarget, Phaser.Camera.FOLLOW_LOCKON, 0.1, 0.1);
    },
    cameraManager: function () {
        var roomHeight = 12 * 16;
        var roomWidth = 17 * 16;
        var posX = Math.floor(player.position.x / roomWidth);
        var posY = Math.floor(player.position.y / roomHeight);
        cameraTarget.position.x = posX * roomWidth + roomWidth / 2 + 8;
        cameraTarget.position.y = posY * roomHeight + roomHeight / 2 + 8;

    },
    createHud: function () {

        this.hud_1 = game.add.sprite(10, 5, "atlas", "hearts/hearts-1");
        this.hud_2 = game.add.sprite(18, 5, "atlas", "hearts/hearts-1");
        this.hud_3 = game.add.sprite(26, 5, "atlas", "hearts/hearts-1");
        this.hud_1.fixedToCamera = true;
        this.hud_2.fixedToCamera = true;
        this.hud_3.fixedToCamera = true;

    },
    addAudios: function () {
        this.audioHurt = game.add.audio("hurt");
        this.audioItem = game.add.audio("item");
        this.audioEnemyDeath = game.add.audio("enemy-death");
        this.audioSlash = game.add.audio("slash");
    },
    startMusic: function () {
        if (!audioFlag) {
            return
        }

        this.music = game.add.audio("music");
        this.music.loop = true;

        this.music.play();

    },
    createTileMap: function (levelNum) {
        if (levelNum == 1) {
            levelNum = "";
        }
        //tilemap
        globalMap = game.add.tilemap("map" + levelNum);
        globalMap.addTilesetImage("collisions");
        globalMap.addTilesetImage("tileset");
        globalMap.addTilesetImage("tileset-foreground");

        this.layer_collisions = globalMap.createLayer("Collisions Layer");
        this.layer = globalMap.createLayer("Main Layer");

        // collisions
        globalMap.setCollision([0, 1]);

        this.layer.resizeWorld();
        this.layer_collisions.resizeWorld();

        this.layer_collisions.visible = true;
        this.layer_collisions.debug = true;
        //this.layer.visible = false;

    },
    createPlayer: function (x, y) {
        var temp = new Player(game, x, y);
        game.add.existing(temp);
        this.createHitbox();
    },
    createHitbox: function () {
        // create hitbox
        this.hitbox = game.add.sprite(0, 0, null);

        this.hitbox.anchor.setTo(0.5);
        game.physics.arcade.enable(this.hitbox);
        this.hitbox.body.setSize(20, 16, 0, 0);
        player.addChild(this.hitbox);
        // slash animation
        this.slash = game.add.sprite(0, 0, "atlas", "slash/slash-blank");
        this.slash.animations.add("slash", ["slash/slash-1", "slash/slash-2", "slash/slash-blank"], 17, false);
        player.addChild(this.slash);
        player_state = PLAYER_STATE.DOWN;

    },
    bindKeys: function () {
        this.wasd = {
            left: game.input.keyboard.addKey(Phaser.Keyboard.LEFT),
            right: game.input.keyboard.addKey(Phaser.Keyboard.RIGHT),
            down: game.input.keyboard.addKey(Phaser.Keyboard.DOWN),
            up: game.input.keyboard.addKey(Phaser.Keyboard.UP),
            attack: game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR)
        }
        game.input.keyboard.addKeyCapture(
            [Phaser.Keyboard.SPACEBAR,
                Phaser.Keyboard.LEFT,
                Phaser.Keyboard.RIGHT,
                Phaser.Keyboard.DOWN,
                Phaser.Keyboard.UP]
        );
    },
    createGroups: function () {
        enemies_group = game.add.group();
        enemies_group.enableBody = true;
        //
        loot_group = game.add.group();
        loot_group.enableBody = true;
        //
        objects_group = game.add.group();
        objects_group.enableBody = true;
    },
    populate: function () {

        // populate enemies from the tiled map from the objects layer
        this.createSlimes();
        this.createSkulls();
        this.createPots();
        this.spawnKey(46,32);
    },

    //find objects in a Tiled layer that containt a property called "type" equal to a certain value
    findObjectsByType: function (type, map, layer) {
        var result = new Array();
        map.objects[layer].forEach(function (element) {
            //console.log(element);
            if (element.type === type) {
                //Phaser uses top left, Tiled bottom left so we have to adjust the y position
                //also keep in mind that the cup images are a bit smaller than the tile which is 16x16
                //so they might not be placed in the exact pixel position as in Tiled
                //console.log("Found " + element.type);
                element.y -= map.tileHeight;

                result.push(element);
            }
        });
        return result;
    },

    createPots: function () {
        var items_array = this.findObjectsByType("pot", globalMap, "Object Layer");
        for (var i = 0; i < items_array.length; i++) {
            var sprite = objects_group.add(new Pot(game, items_array[i].x, items_array[i].y)); // create prefab
        }

    },

    createSlimes: function () {
        var enemies_array = this.findObjectsByType("slime", globalMap, "Object Layer");
        //console.log(enemies_array);
        for (var i = 0; i < enemies_array.length; i++) {
            var sprite = enemies_group.add(new Slime(game, enemies_array[i].x / 16, enemies_array[i].y / 16)); // create prefab
        }

    },

    createSkulls: function () {
        var enemies_array = this.findObjectsByType("skull", globalMap, "Object Layer");
        //console.log(slimes_array);
        for (var i = 0; i < enemies_array.length; i++) {
            var sprite = enemies_group.add(new Skull(game, enemies_array[i].x / 16, enemies_array[i].y / 16, enemies_array[i].properties.vertical)); // create prefab
        }

    },

    spawnEnemyDeath: function (x, y) {
        var temp = new EnemyDeath(game, x, y);
        game.add.existing(temp);
    },
    spawnHeart: function (x, y) {
        var temp = new Heart(game, x, y);
        game.add.existing(temp);
        loot_group.add(temp);
    },
    spawnKey: function (x, y) {
        var temp = new Key(game, x, y);
        game.add.existing(temp);
        loot_group.add(temp);
    },
    update: function () {

        // physics
        game.physics.arcade.collide(player, this.layer_collisions);
        game.physics.arcade.collide(enemies_group, this.layer_collisions);
        game.physics.arcade.collide(player, objects_group);

        if (player.alive) {

            //overlaps
            game.physics.arcade.overlap(player, enemies_group, this.hurtPlayer, null, this);
            game.physics.arcade.overlap(this.hitbox, enemies_group, this.slashManager, null, this);
            game.physics.arcade.overlap(this.hitbox, objects_group, this.slashManager, null, this);
            game.physics.arcade.overlap(player, loot_group, this.lootManager, null, this);

            // exit game if key is obtained
            game.physics.arcade.overlap(player, exit, this.exitManager, null, this);
        }

        this.movePlayer();
        this.hurtManager();
        this.cameraManager();
        // this.debugGame();
    },
    exitManager: function (player, exit) {
        if(exitFlag){
            this.game.state.start("TitleScreen");
            this.music.stop();
        }


    },
    lootManager: function (player, loot) {
        if (loot.type == "heart") {
            this.audioItem.play();
            loot.kill();
            if (player.health < 3) {
                player.health++;
                this.updateHealthHud();
            }

        }
        if (loot.type == "key") {
            this.audioItem.play();
            loot.kill();
            exitFlag = true;
            exit.animations.play("open");

        }

    },
    slashManager: function (hitbox, enemy) {

        if (this.wasd.attack.isDown) {
            enemy.destroy();
            this.audioEnemyDeath.play();
            this.spawnEnemyDeath(enemy.x, enemy.y);
            // sometimes drop hearts
            if (game.rnd.integerInRange(0, 2) == 0) {
                this.spawnHeart(enemy.x / 16, enemy.y / 16);
            }

        }

    },
    gameOver: function () {
        this.music.stop();
        this.game.state.start("GameOver");
    },
    hurtPlayer: function () {

        if (hurtFlag) {
            return;
        }
        hurtFlag = true;
        this.game.time.reset();

        player.alpha = 0.5;

        player.health--;
        this.updateHealthHud();

        this.audioHurt.play();
        if (player.health < 1) {
            this.gameOver();

        }
    },
    hurtManager: function () {
        if (hurtFlag && this.game.time.totalElapsedSeconds() > 2) {
            hurtFlag = false;
            player.alpha = 1;
        }
    },
    updateHealthHud: function () {
        switch (player.health) {
            case 3:
                this.hud_1.loadTexture("atlas", "hearts/hearts-1", false);
                this.hud_2.loadTexture("atlas", "hearts/hearts-1", false);
                this.hud_3.loadTexture("atlas", "hearts/hearts-1", false);
                break;
            case 2:
                this.hud_1.loadTexture("atlas", "hearts/hearts-1", false);
                this.hud_2.loadTexture("atlas", "hearts/hearts-1", false);
                this.hud_3.loadTexture("atlas", "hearts/hearts-2", false);
                break;
            case 1:
                this.hud_1.loadTexture("atlas", "hearts/hearts-1", false);
                this.hud_2.loadTexture("atlas", "hearts/hearts-2", false);
                this.hud_3.loadTexture("atlas", "hearts/hearts-2", false);
                break;
            case 0:
                this.hud_1.loadTexture("atlas", "hearts/hearts-2", false);
                this.hud_2.loadTexture("atlas", "hearts/hearts-2", false);
                this.hud_3.loadTexture("atlas", "hearts/hearts-2", false);

                break;
        }
    },
    movePlayer: function () {

        // attack animations
        if (this.wasd.attack.isDown && !attackFlag) {
            this.slash.animations.play("slash");
            this.audioSlash.play();
            attackFlag = true;
        }

        if (attackFlag) {

            player.body.velocity.x = 0;
            player.body.velocity.y = 0;
            return;
        }

        var vel = 50;

        // capture input
        if (this.wasd.down.isDown) {
            player_state = PLAYER_STATE.WALKING_DOWN;
            player.body.velocity.y = vel;
            player.body.velocity.x = 0;
            //
            this.hitbox.x = 6;
            this.hitbox.y = 34;
            //
            this.slash.scale.y = -1;
            this.slash.scale.x = -1;
            this.slash.angle = 0;
            this.slash.x = 16;
            this.slash.y = 24;
        } else if (this.wasd.up.isDown) {
            player_state = PLAYER_STATE.WALKING_UP;
            player.body.velocity.y = -vel;
            player.body.velocity.x = 0;
            //
            this.hitbox.x = 6;
            this.hitbox.y = 0;
            //
            this.slash.scale.y = 1;
            this.slash.scale.x = 1;
            this.slash.angle = 0;
            this.slash.x = -16;
            this.slash.y = -16;
        } else if (this.wasd.left.isDown) {
            player_state = PLAYER_STATE.WALKING_LEFT;
            player.body.velocity.x = -vel;
            player.body.velocity.y = 0;
            //
            this.hitbox.x = 16;
            this.hitbox.y = 16;
            //
            this.slash.scale.y = 1;
            this.slash.scale.x = 1;
            this.slash.angle = 90;
            this.slash.x = 22;
            this.slash.y = -10;
        } else if (this.wasd.right.isDown) {
            player_state = PLAYER_STATE.WALKING_RIGHT;
            player.body.velocity.x = vel;
            player.body.velocity.y = 0;
            //
            this.hitbox.x = 28;
            this.hitbox.y = 16;
            //
            this.slash.scale.y = 1;
            this.slash.scale.x = 1;
            this.slash.angle = 90;
            this.slash.x = 22;
            this.slash.y = -10;
        } else {
            player.body.velocity.y = 0;
            player.body.velocity.x = 0;
        }

        // idle
        if (player_state == PLAYER_STATE.WALKING_DOWN && player.body.velocity.y == 0) {
            player_state = PLAYER_STATE.DOWN;
        } else if (player_state == PLAYER_STATE.WALKING_UP && player.body.velocity.y == 0) {
            player_state = PLAYER_STATE.UP;
        } else if (player_state == PLAYER_STATE.WALKING_LEFT && player.body.velocity.x == 0) {
            player_state = PLAYER_STATE.LEFT;
        } else if (player_state == PLAYER_STATE.WALKING_RIGHT && player.body.velocity.x == 0) {
            player_state = PLAYER_STATE.RIGHT;
        }

    },
    debugGame: function () {
        //game.debug.spriteInfo(this.player, 30, 30);

        // game.debug.body(player);
        // game.debug.body(this.hitbox);
        // game.debug.body(this.slash);
        game.debug.body(cameraTarget);

        //  enemies_group.forEachAlive(this.renderGroup, this);
        // loot_group.forEachAlive(this.renderGroup, this);

    },
    renderGroup: function (member) {
        game.debug.body(member);
    }

}

// player

Player = function (game, x, y) {
    x *= 16;
    y *= 16;
    this.initX = x;
    this.initY = y;
    this.health = 3;
    Phaser.Sprite.call(this, game, x, y, "atlas", "idle/hero-male-front-idle");
    this.anchor.setTo(0.5);
    game.physics.arcade.enable(this);
    this.body.setSize(13, 10, 10, 20);
    //add animations
    var animVel = 12;
    this.animations.add('idle-front', ['idle/hero-male-front-idle'], 0, true);
    this.animations.add('idle-back', ['idle/hero-male-back-idle'], 0, true);
    this.animations.add('idle-side', ['idle/hero-male-side-idle'], 0, true);
    //
    this.animations.add('walk-front', Phaser.Animation.generateFrameNames('walk/front-walk/hero-male-front-walk-', 1, 6, '', 0), animVel, true);
    this.animations.add('walk-back', Phaser.Animation.generateFrameNames('walk/back-walk/hero-male-back-walk-', 1, 6, '', 0), animVel, true);
    this.animations.add('walk-side', Phaser.Animation.generateFrameNames('walk/side-walk/hero-male-side-walk-', 1, 6, '', 0), animVel, true);
    //
    var attack_front = this.animations.add('attack-front', Phaser.Animation.generateFrameNames('attack/front-attack/hero-male-front-attack-', 1, 4, '', 0), animVel, false);
    var attack_back = this.animations.add('attack-back', Phaser.Animation.generateFrameNames('attack/back-attack/hero-male-back-attack-', 1, 4, '', 0), animVel, false);
    var attack_side = this.animations.add('attack-side', Phaser.Animation.generateFrameNames('attack/side-attack/hero-male-side-attack-', 1, 4, '', 0), animVel, false);
    // set flag to false on complete
    attack_front.onComplete.add(resetAttackFlag, this);
    attack_back.onComplete.add(resetAttackFlag, this);
    attack_side.onComplete.add(resetAttackFlag, this);

    function resetAttackFlag() {
        attackFlag = false;
    }

    this.animations.play("idle-front");
    this.type = "player";
    player = this;

}
Player.prototype = Object.create(Phaser.Sprite.prototype);
Player.prototype.constructor = Player;
Player.prototype.update = function () {

    // player attack animation
    if (attackFlag) {

        if (player_state == PLAYER_STATE.WALKING_DOWN || player_state == PLAYER_STATE.DOWN) {
            this.animations.play("attack-front");
        } else if (player_state == PLAYER_STATE.WALKING_UP || player_state == PLAYER_STATE.UP) {
            this.animations.play("attack-back");
        } else if (player_state == PLAYER_STATE.WALKING_LEFT || player_state == PLAYER_STATE.LEFT) {
            this.animations.play("attack-side");
        } else if (player_state == PLAYER_STATE.WALKING_RIGHT || player_state == PLAYER_STATE.RIGHT) {
            this.animations.play("attack-side");
        }
        return;
    }

    // player walk animation
    if (player_state == PLAYER_STATE.WALKING_DOWN) {
        this.animations.play("walk-front");
        this.scale.x = 1;
    } else if (player_state == PLAYER_STATE.WALKING_UP) {
        this.animations.play("walk-back");
        this.scale.x = 1;
    } else if (player_state == PLAYER_STATE.WALKING_LEFT) {
        this.animations.play("walk-side");
        this.scale.x = -1;
    } else if (player_state == PLAYER_STATE.WALKING_RIGHT) {
        this.animations.play("walk-side");
        this.scale.x = 1;
    } else if (player_state == PLAYER_STATE.DOWN) {
        this.animations.play("idle-front");
        this.scale.x = 1;
    } else if (player_state == PLAYER_STATE.UP) {
        this.animations.play("idle-back");
        this.scale.x = 1;
    } else if (player_state == PLAYER_STATE.LEFT) {
        this.animations.play("idle-side");
    } else if (player_state == PLAYER_STATE.RIGHT) {
        this.animations.play("idle-side");
    }
}
Player.prototype.reset = function () {
    this.x = this.initX;
    this.y = this.initY;
    this.health = 3;
    this.alive = true;
    this.animations.play('idle');
    hurtFlag = false;

}
Player.prototype.death = function () {
    this.alive = false;
    this.body.velocity.x = 0;
    this.body.velocity.y = -400;
}

// Slime

Slime = function (game, x, y) {
    x *= 16;
    y *= 16;
    Phaser.Sprite.call(this, game, x, y, "atlas", "slime-1");
    this.animations.add('crawl', Phaser.Animation.generateFrameNames('slime-', 1, 4, '', 0), 10, true);
    this.animations.play("crawl");
    this.anchor.setTo(0.5);
    game.physics.arcade.enable(this);
    //this.body.setSize(20, 11, 7, 10);
    this.speed = 40;
    this.moveCounter = 0;
    this.direction = "up";
    this.directionsArray = ["up", "down", "left", "right"];
    this.type = "slug";

}
Slime.prototype = Object.create(Phaser.Sprite.prototype);
Slime.prototype.constructor = Slime;
Slime.prototype.update = function () {
    this.moveCounter++;
    //console.log(this.moveCounter);
    // move around
    if (this.moveCounter == 50) {
        this.direction = this.directionsArray[game.rnd.between(0, this.directionsArray.length - 1)];
    } else if (this.moveCounter > 50) {
        this.move();
    }

    if (this.moveCounter > 70) {
        this.moveCounter = 0;
        this.body.velocity.x = 0;
        this.body.velocity.y = 0;
    }
}
Slime.prototype.move = function () {
    if (this.direction == "left") {
        this.body.velocity.x = -this.speed;
    } else if (this.direction == "right") {
        this.body.velocity.x = this.speed;
    }
    if (this.direction == "up") {
        this.body.velocity.y = -this.speed;
    }
    if (this.direction == "down") {
        this.body.velocity.y = this.speed;
    }

}

// Skull

Skull = function (game, x, y, verticalMove) {
    x *= 16;
    y *= 16;
    Phaser.Sprite.call(this, game, x, y, "atlas", "slime-1");
    this.animations.add('move', Phaser.Animation.generateFrameNames('skull-', 1, 4, '', 0), 10, true);
    this.animations.play("move");
    this.anchor.setTo(0.5);
    game.physics.arcade.enable(this);
    this.body.setSize(11, 12, 3, 14);
    this.speed = 60;
    if (verticalMove) {
        this.body.velocity.y = this.speed;
    } else {
        this.body.velocity.x = this.speed;
    }
    this.body.bounce.x = 1;
    this.body.bounce.y = 1;
    this.type = "skull";

}
Skull.prototype = Object.create(Phaser.Sprite.prototype);
Skull.prototype.constructor = Skull;

// Heart

Heart = function (game, x, y) {
    x *= 16;
    y *= 16;
    Phaser.Sprite.call(this, game, x, y, "atlas", "hearts/hearts-1");
    this.anchor.setTo(0.5);
    game.physics.arcade.enable(this);
    this.type = "heart";
}
Heart.prototype = Object.create(Phaser.Sprite.prototype);
Heart.prototype.constructor = Heart;

// Key

Key = function (game, x, y) {
    x *= 16;
    y *= 16;
    Phaser.Sprite.call(this, game, x, y, "atlas", "key/key-1");
    this.animations.add('key', Phaser.Animation.generateFrameNames('key/key-', 1, 5, '', 0), 10, true);
    this.animations.play("key");
    this.anchor.setTo(0.5);
    game.physics.arcade.enable(this);
    this.type = "key";
}
Key.prototype = Object.create(Phaser.Sprite.prototype);
Key.prototype.constructor = Key;

// Pot

Pot = function (game, x, y) {
    x += 8;
    y += 8;
    Phaser.Sprite.call(this, game, x, y, "atlas-props", "pot");
    this.anchor.setTo(0.5);
    game.physics.arcade.enable(this);
    this.body.immovable = true;
    this.type = "pot";

}
Pot.prototype = Object.create(Phaser.Sprite.prototype);
Pot.prototype.constructor = Pot;

// enemy death

EnemyDeath = function (game, x, y) {
    Phaser.Sprite.call(this, game, x, y, "atlas", "enemy-death/enemy-death-1");
    this.anchor.setTo(0.5);
    var anim = this.animations.add("death", Phaser.Animation.generateFrameNames("enemy-death/enemy-death-", 1, 8, '', 0), 18, false);
    this.animations.play("death");
    anim.onComplete.add(function () {
            this.kill();
        }, this
    );
}

EnemyDeath.prototype = Object.create(Phaser.Sprite.prototype);
EnemyDeath.prototype.constructor = EnemyDeath;